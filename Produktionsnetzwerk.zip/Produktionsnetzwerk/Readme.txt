Dieser Ordner beinhaltet die .alp Datei, die zur Ausf�hrung des Simulationsmodells ben�tigt wird.
Au�erdem sind alle Excel-Dateien in diesem Ordner abzulegen, um das Simulationsmodell zu implementieren.
Beispielhaft ist hier ein kleines Produktionsnetzwerk abgelegt.

Formatvorlagen f�r alle Excel-Dateien, die f�r jeden Produktionsstandort ein Tabellenblatt beinhalten, sind im Ordner Vorlagen abgelegt. 
Dort sind f�r alle relevanten Dateien jeweils Tabellenbl�tter f�r 1-5 Produktvarianten in einem Standort abgelegt.
Aus diesen und eventuell n�tigen Erweiterungen f�r mehr Produktvarianten kann ein eigenes Netzwerk erstellt werden.